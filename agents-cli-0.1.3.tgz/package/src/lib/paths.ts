import { homedir } from "os";
import { join } from "path";

/** Root directory for agents CLI */
export const AGENTS_ROOT = join(homedir(), ".agents");

/** Configuration file path */
export const CONFIG_PATH = join(AGENTS_ROOT, "config.json");

/** Skills module store directory */
export const SKILLS_STORE = join(AGENTS_ROOT, "skills", "store");

/** Commands module directories */
export const COMMANDS_ROOT = join(AGENTS_ROOT, "commands");
export const COMMANDS_SOURCES = join(COMMANDS_ROOT, "sources");
export const COMMANDS_STORE = join(COMMANDS_ROOT, "store");
export const COMMANDS_ALIASES = join(COMMANDS_ROOT, "aliases.json");

/** Hooks directory (user-managed, no sources) */
export const HOOKS_ROOT = join(AGENTS_ROOT, "hooks");

/** AGENTS.md source file (user-managed at ~/.agents/AGENTS.md) */
export const AGENTS_MD_SOURCE = join(AGENTS_ROOT, "AGENTS.md");

export function getSkillPath(name: string): string {
    return join(SKILLS_STORE, name);
}

export function getCommandSourcePath(name: string): string {
    return join(COMMANDS_SOURCES, name);
}
