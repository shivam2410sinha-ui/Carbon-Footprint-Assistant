import { mkdir } from "fs/promises";
import { AGENTS_ROOT, CONFIG_PATH, SKILLS_STORE, COMMANDS_SOURCES, COMMANDS_STORE, HOOKS_ROOT } from "./paths.ts";
import type { SkillsConfig, Source, Target } from "../modules/skills/types.ts";
import type { CommandsConfig, CommandSource, CommandTarget } from "../modules/commands/types.ts";
import type { HooksConfig, HookTarget } from "../modules/hooks/types.ts";
import type { AgentsMdTarget } from "../modules/agents-md/types.ts";

/**
 * Global agents-cli configuration
 */
/**
 * AGENTS.md configuration (targets only, source is always ~/.agents/AGENTS.md)
 */
export interface AgentsMdConfig {
    targets: AgentsMdTarget[];
}

export interface AgentsConfig {
    skills: SkillsConfig;
    commands: CommandsConfig;
    hooks: HooksConfig;
    agentsMd: AgentsMdConfig;
}

const DEFAULT_CONFIG: AgentsConfig = {
    skills: { sources: [], targets: [] },
    commands: { sources: [], targets: [] },
    hooks: { targets: [] },
    agentsMd: { targets: [] },
};

/**
 * Ensure the agents directories exist
 */
export async function ensureDirectories(): Promise<void> {
    await mkdir(AGENTS_ROOT, { recursive: true });
    await mkdir(SKILLS_STORE, { recursive: true });
    await mkdir(COMMANDS_SOURCES, { recursive: true });
    await mkdir(COMMANDS_STORE, { recursive: true });
    await mkdir(HOOKS_ROOT, { recursive: true });
}

/**
 * Read the config file
 */
export async function readConfig(): Promise<AgentsConfig> {
    await ensureDirectories();
    const configFile = Bun.file(CONFIG_PATH);

    if (!(await configFile.exists())) {
        await writeConfig(DEFAULT_CONFIG);
        return DEFAULT_CONFIG;
    }

    try {
        const content = await configFile.json();
        if (!content.skills) content.skills = { sources: [], targets: [] };
        if (!content.commands) content.commands = { sources: [], targets: [] };
        if (!content.hooks) content.hooks = { targets: [] };
        if (!content.agentsMd) content.agentsMd = { targets: [] };
        return content as AgentsConfig;
    } catch {
        await writeConfig(DEFAULT_CONFIG);
        return DEFAULT_CONFIG;
    }
}

/**
 * Write the config file
 */
export async function writeConfig(config: AgentsConfig): Promise<void> {
    await ensureDirectories();
    await Bun.write(CONFIG_PATH, JSON.stringify(config, null, 2));
}

// ==================== Skills Config Helpers ====================

export async function addSkillSource(source: Source): Promise<void> {
    const config = await readConfig();
    if (config.skills.sources.find(s => s.name === source.name)) {
        throw new Error(`Skill with name "${source.name}" already exists`);
    }
    config.skills.sources.push(source);
    await writeConfig(config);
}

export async function removeSkillSource(name: string): Promise<Source | null> {
    const config = await readConfig();
    const index = config.skills.sources.findIndex(s => s.name === name);
    if (index === -1) return null;
    const removed = config.skills.sources.splice(index, 1)[0];
    await writeConfig(config);
    return removed || null;
}

export async function getSkillSources(): Promise<Source[]> {
    const config = await readConfig();
    return config.skills.sources;
}

export async function addSkillTarget(target: Target): Promise<void> {
    const config = await readConfig();
    if (config.skills.targets.find(t => t.name === target.name)) {
        throw new Error(`Target with name "${target.name}" already exists`);
    }
    config.skills.targets.push(target);
    await writeConfig(config);
}

export async function removeSkillTarget(name: string): Promise<Target | null> {
    const config = await readConfig();
    const index = config.skills.targets.findIndex(t => t.name === name);
    if (index === -1) return null;
    const removed = config.skills.targets.splice(index, 1)[0];
    await writeConfig(config);
    return removed || null;
}

export async function getSkillTargets(): Promise<Target[]> {
    const config = await readConfig();
    return config.skills.targets;
}

// ==================== Commands Config Helpers ====================

export async function addCommandSource(source: CommandSource): Promise<void> {
    const config = await readConfig();
    if (config.commands.sources.find(s => s.name === source.name)) {
        throw new Error(`Command source with name "${source.name}" already exists`);
    }
    config.commands.sources.push(source);
    await writeConfig(config);
}

export async function removeCommandSource(name: string): Promise<CommandSource | null> {
    const config = await readConfig();
    const index = config.commands.sources.findIndex(s => s.name === name);
    if (index === -1) return null;
    const removed = config.commands.sources.splice(index, 1)[0];
    await writeConfig(config);
    return removed || null;
}

export async function getCommandSources(): Promise<CommandSource[]> {
    const config = await readConfig();
    return config.commands.sources;
}

export async function addCommandTarget(target: CommandTarget): Promise<void> {
    const config = await readConfig();
    if (config.commands.targets.find(t => t.name === target.name)) {
        throw new Error(`Command target with name "${target.name}" already exists`);
    }
    config.commands.targets.push(target);
    await writeConfig(config);
}

export async function removeCommandTarget(name: string): Promise<CommandTarget | null> {
    const config = await readConfig();
    const index = config.commands.targets.findIndex(t => t.name === name);
    if (index === -1) return null;
    const removed = config.commands.targets.splice(index, 1)[0];
    await writeConfig(config);
    return removed || null;
}

export async function getCommandTargets(): Promise<CommandTarget[]> {
    const config = await readConfig();
    return config.commands.targets;
}

// ==================== Hooks Config Helpers (targets only) ====================

export async function addHookTarget(target: HookTarget): Promise<void> {
    const config = await readConfig();
    if (config.hooks.targets.find(t => t.name === target.name)) {
        throw new Error(`Hook target with name "${target.name}" already exists`);
    }
    config.hooks.targets.push(target);
    await writeConfig(config);
}

export async function removeHookTarget(name: string): Promise<HookTarget | null> {
    const config = await readConfig();
    const index = config.hooks.targets.findIndex(t => t.name === name);
    if (index === -1) return null;
    const removed = config.hooks.targets.splice(index, 1)[0];
    await writeConfig(config);
    return removed || null;
}

export async function getHookTargets(): Promise<HookTarget[]> {
    const config = await readConfig();
    return config.hooks.targets;
}

// ==================== AGENTS.md Config Helpers (targets only) ====================

export async function addAgentsMdTarget(target: AgentsMdTarget): Promise<void> {
    const config = await readConfig();
    if (config.agentsMd.targets.find(t => t.name === target.name)) {
        throw new Error(`AGENTS.md target with name "${target.name}" already exists`);
    }
    config.agentsMd.targets.push(target);
    await writeConfig(config);
}

export async function removeAgentsMdTarget(name: string): Promise<AgentsMdTarget | null> {
    const config = await readConfig();
    const index = config.agentsMd.targets.findIndex(t => t.name === name);
    if (index === -1) return null;
    const removed = config.agentsMd.targets.splice(index, 1)[0];
    await writeConfig(config);
    return removed || null;
}

export async function getAgentsMdTargets(): Promise<AgentsMdTarget[]> {
    const config = await readConfig();
    return config.agentsMd.targets;
}
