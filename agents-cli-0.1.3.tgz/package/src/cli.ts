#!/usr/bin/env bun

import chalk from "chalk";
import { handleSkillsCommand } from "./modules/skills/index.ts";
import { handleCommandsCommand } from "./modules/commands/index.ts";
import { handleHooksCommand } from "./modules/hooks/index.ts";
import { handleAgentsMdCommand } from "./modules/agents-md/index.ts";
import { selfUpdate, checkForUpdate } from "./commands/self-update.ts";

const VERSION = "0.1.1";

function printHelp() {
  console.log(`
${chalk.bold("agents")} - One CLI for all agent-related configurations

${chalk.bold("USAGE")}
  ${chalk.cyan("agents")} <module> <command> [options]
  ${chalk.cyan("agents update")}  Update to latest version

${chalk.bold("MODULES")}
  ${chalk.cyan("skills")}       Manage AI skills
  ${chalk.cyan("commands")}     Manage command files
  ${chalk.cyan("hooks")}        Manage hook files
  ${chalk.cyan("agents-md")}    Manage AGENTS.md file
  ${chalk.cyan("update")}       Update CLI to latest version

${chalk.bold("OPTIONS")}
  ${chalk.cyan("--help, -h")}   Show help
  ${chalk.cyan("--version, -v")} Show version

${chalk.bold("EXAMPLES")}
  ${chalk.cyan("agents skills source add")} https://github.com/user/repo --remote
  ${chalk.cyan("agents commands source add")} ./my-commands --local
  ${chalk.cyan("agents hooks target add")} claude
`);
}

async function main() {
  const args = process.argv.slice(2);

  if (args.length === 0) {
    // Check for updates in interactive mode
    await checkForUpdate();
    printHelp();
    process.exit(0);
  }

  if (args[0] === "--help" || args[0] === "-h") {
    printHelp();
    process.exit(0);
  }

  if (args[0] === "--version" || args[0] === "-v") {
    console.log(`agents v${VERSION}`);
    process.exit(0);
  }

  const module = args[0];

  try {
    switch (module) {
      case "skills":
        await handleSkillsCommand(args.slice(1));
        break;

      case "commands":
        await handleCommandsCommand(args.slice(1));
        break;

      case "hooks":
        await handleHooksCommand(args.slice(1));
        break;

      case "agents-md":
        await handleAgentsMdCommand(args.slice(1));
        break;

      case "update":
      case "self-update":
        await selfUpdate();
        break;

      case "help":
        printHelp();
        break;

      default:
        console.error(chalk.red(`Unknown module: ${module}`));
        console.log(`Run ${chalk.cyan("agents --help")} for usage.`);
        process.exit(1);
    }
  } catch (error) {
    console.error(chalk.red(`Error: ${error instanceof Error ? error.message : error}`));
    process.exit(1);
  }
}

main();