import { readdir } from "fs/promises";
import chalk from "chalk";
import Table from "cli-table3";
import { getSkillSources, getSkillTargets } from "../../../lib/config.ts";
import { SKILLS_STORE, getSkillPath } from "../../../lib/paths.ts";
import { directoryExists } from "../../../lib/hash.ts";

/**
 * Show overview of skills, targets & sync state
 */
export async function status(): Promise<void> {
    const sources = await getSkillSources();
    const targets = await getSkillTargets();

    console.log();
    console.log(chalk.bold("Skills CLI Status"));
    console.log(chalk.dim("─".repeat(50)));
    console.log();

    // Skills summary
    console.log(chalk.bold("Skills:"));
    if (sources.length === 0) {
        console.log(chalk.dim("  No skills registered"));
    } else {
        const table = new Table({
            head: [chalk.bold("Name"), chalk.bold("Type"), chalk.bold("Status")],
            style: { head: [], border: [] },
        });

        for (const source of sources) {
            const exists = await directoryExists(getSkillPath(source.name));
            table.push([
                source.name,
                source.type,
                exists ? chalk.green("OK") : chalk.red("MISSING"),
            ]);
        }

        console.log(table.toString());
    }

    console.log();

    // Targets summary
    console.log(chalk.bold("Targets:"));
    if (targets.length === 0) {
        console.log(chalk.dim("  No targets registered"));
    } else {
        const table = new Table({
            head: [chalk.bold("Name"), chalk.bold("Path"), chalk.bold("Status")],
            style: { head: [], border: [] },
        });

        for (const target of targets) {
            const exists = await directoryExists(target.path);
            table.push([
                target.name,
                target.path,
                exists ? chalk.green("OK") : chalk.red("MISSING"),
            ]);
        }

        console.log(table.toString());
    }

    console.log();

    // Quick stats
    console.log(chalk.bold("Summary:"));
    console.log(`  Skills: ${sources.length}`);
    console.log(`  Targets: ${targets.length}`);

    // Store info
    const storeExists = await directoryExists(SKILLS_STORE);
    if (storeExists) {
        try {
            const storeContents = await readdir(SKILLS_STORE);
            console.log(`  Store: ${storeContents.length} skill(s) in ${chalk.dim(SKILLS_STORE)}`);
        } catch {
            console.log(`  Store: ${chalk.dim(SKILLS_STORE)}`);
        }
    } else {
        console.log(`  Store: ${chalk.dim("empty")}`);
    }

    console.log();
}
