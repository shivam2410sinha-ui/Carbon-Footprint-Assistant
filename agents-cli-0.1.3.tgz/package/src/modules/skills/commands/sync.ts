import { mkdir, readdir, symlink, rm, lstat } from "fs/promises";
import { join } from "path";
import chalk from "chalk";
import { getSkillTargets } from "../../../lib/config.ts";
import { SKILLS_STORE } from "../../../lib/paths.ts";
import { directoryExists } from "../../../lib/hash.ts";
import type { Target } from "../types.ts";

/**
 * Create a symlink, using junction on Windows for directory symlinks
 * Junctions work without admin privileges on Windows
 */
async function createSymlink(source: string, target: string): Promise<void> {
    const isWindows = process.platform === "win32";

    // Remove existing symlink or file if present
    try {
        const stats = await lstat(target);
        if (stats.isSymbolicLink() || stats.isFile() || stats.isDirectory()) {
            await rm(target, { recursive: true, force: true });
        }
    } catch {
        // Target doesn't exist, which is fine
    }

    // Create symlink (junction on Windows for directories)
    await symlink(source, target, isWindows ? "junction" : "dir");
}

/**
 * Sync a single target with the store using symlinks
 */
export async function syncToTarget(target: Target): Promise<void> {
    // Check if store has content
    const storeExists = await directoryExists(SKILLS_STORE);
    if (!storeExists) {
        console.log(`  ${target.name}: Store is empty, nothing to sync`);
        return;
    }

    try {
        const skills = await readdir(SKILLS_STORE);
        if (skills.length === 0) {
            console.log(`  ${target.name}: Store is empty, nothing to sync`);
            return;
        }

        // Remove target directory/symlink if it exists
        // We want to replace the folder with a symlink to the store
        try {
            const stats = await lstat(target.path);
            if (stats.isSymbolicLink() || stats.isDirectory() || stats.isFile()) {
                await rm(target.path, { recursive: true, force: true });
            }
        } catch {
            // Target doesn't exist, which is fine
        }

        // Ensure parent directory exists
        const parentDir = join(target.path, "..");
        await mkdir(parentDir, { recursive: true });

        // Symlink the entire store folder to the target path
        await createSymlink(SKILLS_STORE, target.path);

        console.log(`  ${target.name}: Synced ${skills.length} skill(s) via store symlink`);
    } catch (error) {
        throw new Error(`Failed to sync ${target.name}: ${error instanceof Error ? error.message : error}`);
    }
}

/**
 * Sync all targets with the store using symlinks
 */
export async function sync(): Promise<void> {
    const targets = await getSkillTargets();

    if (targets.length === 0) {
        console.log("No targets registered.");
        console.log(`Add a target with: ${chalk.cyan("agents skills target add <name>")}`);
        return;
    }

    const storeExists = await directoryExists(SKILLS_STORE);
    if (!storeExists) {
        console.log("Store is empty. Add sources first with: agents skills source add <url> --remote");
        return;
    }

    console.log("Syncing skills to all targets (using symlinks)...\n");

    for (const target of targets) {
        try {
            await syncToTarget(target);
        } catch (error) {
            console.error(`  ${target.name}: Failed - ${error instanceof Error ? error.message : error}`);
        }
    }

    console.log("\nSync complete.");
}
