import { resolve } from "path";
import { mkdir, readdir, symlink, rm, lstat } from "fs/promises";
import chalk from "chalk";
import Table from "cli-table3";
import { addSkillTarget, removeSkillTarget, getSkillTargets } from "../../../lib/config.ts";
import { SKILLS_STORE } from "../../../lib/paths.ts";
import { directoryExists } from "../../../lib/hash.ts";
import { syncToTarget } from "./sync.ts";
import { getKnownTarget, KNOWN_TARGETS } from "../lib/known-targets.ts";
import type { Target } from "../types.ts";

/**
 * Add a target directory
 */
export async function targetAdd(name: string, path?: string): Promise<void> {
    let absolutePath: string;

    if (path) {
        absolutePath = resolve(path.replace(/^~/, process.env.HOME || process.env.USERPROFILE || ""));
    } else {
        const known = getKnownTarget(name);
        if (!known) {
            console.error(chalk.red(`Unknown target: ${name}`));
            console.log(`\nRun ${chalk.cyan("agents skills target available")} to see predefined targets.`);
            console.log(`Or specify a custom path: ${chalk.cyan(`agents skills target add ${name} <path>`)}`);
            process.exit(1);
        }
        absolutePath = known.path;
        console.log(`Using predefined path for ${chalk.cyan(known.description)}`);
    }

    console.log(`Adding target: ${chalk.cyan(name)}`);
    console.log(`Path: ${absolutePath}`);

    // Create the target directory if it doesn't exist
    await mkdir(absolutePath, { recursive: true });

    // Add to config
    await addSkillTarget({
        name,
        path: absolutePath,
    });

    console.log(chalk.green(`Successfully registered target: ${name}`));

    // Perform initial sync
    console.log("Performing initial sync...");
    await syncToTarget({ name, path: absolutePath });

    console.log(chalk.green(`Target "${name}" is now synced.`));
}

/**
 * Show available predefined targets
 */
export async function targetAvailable(): Promise<void> {
    const existingTargets = await getSkillTargets();
    const existingNames = new Set(existingTargets.map(t => t.name.toLowerCase()));

    console.log();
    console.log(chalk.bold("Available Predefined Targets"));
    console.log(chalk.dim("─".repeat(60)));
    console.log();

    const table = new Table({
        head: [
            chalk.bold("Name"),
            chalk.bold("Description"),
            chalk.bold("Path"),
            chalk.bold("Added"),
        ],
        style: {
            head: [],
            border: [],
        },
    });

    for (const target of KNOWN_TARGETS) {
        const isAdded = existingNames.has(target.name.toLowerCase());
        const addedStatus = isAdded ? chalk.green("✓") : chalk.dim("-");

        table.push([
            target.name,
            target.description,
            target.path,
            addedStatus,
        ]);
    }

    console.log(table.toString());
    console.log();
    console.log(chalk.bold("Usage:"));
    console.log(`  ${chalk.cyan("agents skills target add <name>")}              Add a predefined target`);
    console.log(`  ${chalk.cyan("agents skills target add <name> <path>")}       Add a custom target`);
    console.log();
}

/**
 * Remove a target by name
 */
export async function targetRemove(name: string): Promise<void> {
    const removed = await removeSkillTarget(name);

    if (!removed) {
        throw new Error(`Target not found: ${name}`);
    }

    console.log(`Removed target: ${name}`);
    console.log(`Note: Symlinks at ${removed.path} were not deleted.`);
}

/**
 * Check if a target is synced (has symlinks to store)
 */
async function getTargetSyncStatus(target: Target): Promise<"synced" | "not synced" | "target missing"> {
    const targetExists = await directoryExists(target.path);
    if (!targetExists) {
        return "target missing";
    }

    const storeExists = await directoryExists(SKILLS_STORE);
    if (!storeExists) {
        return "not synced";
    }

    try {
        const storeSkills = await readdir(SKILLS_STORE);
        const targetSkills = await readdir(target.path);

        // Check if all store skills have symlinks in target
        for (const skill of storeSkills) {
            if (!targetSkills.includes(skill)) {
                return "not synced";
            }

            // Check if it's a symlink
            try {
                const stats = await lstat(`${target.path}/${skill}`);
                if (!stats.isSymbolicLink()) {
                    return "not synced";
                }
            } catch {
                return "not synced";
            }
        }

        return "synced";
    } catch {
        return "not synced";
    }
}

/**
 * List all targets with sync status
 */
export async function targetList(): Promise<void> {
    const targets = await getSkillTargets();

    if (targets.length === 0) {
        console.log("No targets registered.");
        console.log(`Add a target with: ${chalk.cyan("agents skills target add <name>")}`);
        return;
    }

    const table = new Table({
        head: [
            chalk.bold("Name"),
            chalk.bold("Path"),
            chalk.bold("Status"),
        ],
        style: {
            head: [],
            border: [],
        },
    });

    for (const target of targets) {
        const status = await getTargetSyncStatus(target);
        let statusDisplay: string;

        if (status === "synced") {
            statusDisplay = chalk.green("synced");
        } else if (status === "not synced") {
            statusDisplay = chalk.yellow("outdated");
        } else {
            statusDisplay = chalk.red("missing");
        }

        table.push([
            target.name,
            target.path,
            statusDisplay,
        ]);
    }

    console.log();
    console.log(table.toString());
    console.log();
}
