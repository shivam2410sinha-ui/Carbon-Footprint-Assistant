import { $ } from "bun";
import { rm, cp, mkdir } from "fs/promises";
import chalk from "chalk";
import { getSkillSources } from "../../../lib/config.ts";
import { getSkillPath, SKILLS_STORE } from "../../../lib/paths.ts";
import { directoryExists } from "../../../lib/hash.ts";
import { parseGitUrl } from "../lib/git-url.ts";
import { sync } from "./sync.ts";

/**
 * Update all skills from their origins
 */
export async function update(): Promise<void> {
    const sources = await getSkillSources();

    if (sources.length === 0) {
        console.log("No sources registered.");
        console.log(`Add a source with: ${chalk.cyan("agents skills source add <url> --remote")}`);
        return;
    }

    console.log("Updating skills from origins...\n");

    let updated = 0;
    let failed = 0;

    for (const source of sources) {
        const skillPath = getSkillPath(source.name);

        try {
            if (source.type === "remote" && source.url) {
                console.log(`  ${source.name}: Updating from remote...`);

                const parsed = parseGitUrl(source.url);
                if (!parsed) {
                    console.log(`  ${source.name}: ${chalk.red("Invalid URL")}`);
                    failed++;
                    continue;
                }

                const branch = parsed.branch || "main";
                const cloneUrl = parsed.cloneUrl;

                // Remove existing and re-clone
                await rm(skillPath, { recursive: true, force: true });
                await mkdir(SKILLS_STORE, { recursive: true });

                if (parsed.subdir) {
                    const tempPath = `${skillPath}_temp`;

                    await $`git clone --filter=blob:none --no-checkout --depth 1 --branch ${branch} ${cloneUrl} ${tempPath}`.quiet();
                    await $`git -C ${tempPath} sparse-checkout init --cone`.quiet();
                    await $`git -C ${tempPath} sparse-checkout set ${parsed.subdir}`.quiet();
                    await $`git -C ${tempPath} checkout`.quiet();

                    const subdirFullPath = `${tempPath}/${parsed.subdir}`;
                    await cp(subdirFullPath, skillPath, { recursive: true });
                    await rm(tempPath, { recursive: true, force: true });
                } else {
                    await $`git clone --depth 1 --branch ${branch} ${cloneUrl} ${skillPath}`.quiet();
                    await rm(`${skillPath}/.git`, { recursive: true, force: true });
                }

                console.log(`  ${source.name}: ${chalk.green("Updated")}`);
                updated++;

            } else if (source.type === "local" && source.path) {
                console.log(`  ${source.name}: Syncing from local...`);

                if (!(await directoryExists(source.path))) {
                    console.log(`  ${source.name}: ${chalk.red("Source folder missing")}`);
                    failed++;
                    continue;
                }

                // Remove existing and re-copy
                await rm(skillPath, { recursive: true, force: true });
                await cp(source.path, skillPath, { recursive: true });

                console.log(`  ${source.name}: ${chalk.green("Updated")}`);
                updated++;
            }
        } catch (error) {
            console.log(`  ${source.name}: ${chalk.red(`Failed - ${error instanceof Error ? error.message : error}`)}`);
            failed++;
        }
    }

    console.log();
    console.log(`Updated: ${updated}, Failed: ${failed}`);

    if (updated > 0) {
        console.log("\nRe-syncing targets...");
        await sync();
    }
}
