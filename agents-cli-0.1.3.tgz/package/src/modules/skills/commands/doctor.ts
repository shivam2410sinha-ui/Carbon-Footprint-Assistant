import chalk from "chalk";
import { getSkillSources, getSkillTargets } from "../../../lib/config.ts";
import { SKILLS_STORE, CONFIG_PATH, getSkillPath } from "../../../lib/paths.ts";
import { directoryExists } from "../../../lib/hash.ts";

interface DiagnosticResult {
    check: string;
    status: "ok" | "warning" | "error";
    message: string;
}

/**
 * Run diagnostic checks
 */
export async function doctor(): Promise<void> {
    console.log();
    console.log(chalk.bold("Skills Doctor"));
    console.log(chalk.dim("Running diagnostic checks..."));
    console.log();

    const results: DiagnosticResult[] = [];

    // Check if config file exists
    const configExists = await Bun.file(CONFIG_PATH).exists();
    results.push({
        check: "Config file",
        status: configExists ? "ok" : "warning",
        message: configExists ? CONFIG_PATH : "Config file not found (will be created on first use)",
    });

    // Check if store directory exists
    const storeExists = await directoryExists(SKILLS_STORE);
    results.push({
        check: "Store directory",
        status: storeExists ? "ok" : "warning",
        message: storeExists ? SKILLS_STORE : "Store directory not found (will be created on first source add)",
    });

    // Check sources
    const sources = await getSkillSources();
    for (const source of sources) {
        const skillPath = getSkillPath(source.name);
        const exists = await directoryExists(skillPath);
        results.push({
            check: `Skill: ${source.name}`,
            status: exists ? "ok" : "error",
            message: exists ? "Files present" : "Missing from store - run 'agents skills update'",
        });
    }

    // Check targets
    const targets = await getSkillTargets();
    for (const target of targets) {
        const exists = await directoryExists(target.path);
        results.push({
            check: `Target: ${target.name}`,
            status: exists ? "ok" : "error",
            message: exists ? target.path : "Directory not found",
        });
    }

    // Check Git availability
    try {
        const proc = Bun.spawn(["git", "--version"], { stdout: "pipe" });
        const output = await new Response(proc.stdout).text();
        results.push({
            check: "Git",
            status: "ok",
            message: output.trim(),
        });
    } catch {
        results.push({
            check: "Git",
            status: "error",
            message: "Git not found - required for remote sources",
        });
    }

    // Display results
    for (const result of results) {
        const icon = result.status === "ok"
            ? chalk.green("✓")
            : result.status === "warning"
                ? chalk.yellow("!")
                : chalk.red("✗");

        const statusColor = result.status === "ok"
            ? chalk.green
            : result.status === "warning"
                ? chalk.yellow
                : chalk.red;

        console.log(`${icon} ${chalk.bold(result.check)}: ${statusColor(result.message)}`);
    }

    console.log();

    // Summary
    const errors = results.filter(r => r.status === "error").length;
    const warnings = results.filter(r => r.status === "warning").length;

    if (errors > 0) {
        console.log(chalk.red(`${errors} error(s) found. Please fix the issues above.`));
    } else if (warnings > 0) {
        console.log(chalk.yellow(`${warnings} warning(s) found, but everything should work.`));
    } else {
        console.log(chalk.green("All checks passed!"));
    }

    console.log();
}
