import * as p from "@clack/prompts";
import { lstat, rm, symlink, mkdir } from "fs/promises";
import { resolve } from "path";
import chalk from "chalk";
import Table from "cli-table3";
import { addHookTarget, removeHookTarget, getHookTargets } from "../../lib/config.ts";
import { HOOKS_ROOT } from "../../lib/paths.ts";
import { getKnownHookTarget, KNOWN_HOOK_TARGETS } from "./lib/known-targets.ts";
import type { HookTarget } from "./types.ts";

function printHooksHelp() {
    console.log(`
${chalk.bold("agents hooks")} - Manage hook symlinks across AI tools

${chalk.bold("USAGE")}
  ${chalk.cyan("agents hooks")} <command> [options]

${chalk.bold("COMMANDS")}
  ${chalk.cyan("status")}             Show hook targets and sync status
  ${chalk.cyan("target list")}        List all targets
  ${chalk.cyan("target available")}   Show predefined targets
  ${chalk.cyan("target add")} [name]  Add a target
  ${chalk.cyan("target remove")} [n]  Remove a target
  ${chalk.cyan("sync")}               Sync hooks to all targets

${chalk.bold("NOTES")}
  Hooks are user-managed at ~/.agents/hooks/
  - Edit hooks.json manually
  - Add shell scripts to ~/.agents/hooks/file/
  This CLI just symlinks ~/.agents/hooks/ to targets
`);
}

/**
 * Helper to safely create a symlink, removing existing file/link if needed
 */
async function safeSymlink(source: string, target: string, type: "file" | "dir" | "junction"): Promise<void> {
    try {
        const stats = await lstat(target);
        if (stats.isSymbolicLink() || stats.isFile() || stats.isDirectory()) {
            await rm(target, { recursive: true, force: true });
        }
    } catch { /* Doesn't exist */ }

    await symlink(source, target, type);
}

/**
 * Sync hooks to a target
 */
async function syncToTarget(target: HookTarget): Promise<void> {
    const isWindows = process.platform === "win32";

    // Special handling for Cursor: Split sync to avoid wiping ~/.cursor
    if (target.name.toLowerCase() === "cursor") {
        // 1. Link hooks.json -> ~/.cursor/hooks.json
        await safeSymlink(
            resolve(HOOKS_ROOT, "hooks.json"),
            resolve(target.path, "hooks.json"),
            "file"
        );

        // 2. Link file/ -> ~/.cursor/hooks/
        // Ensure source 'file' dir exists so symlink is valid
        await mkdir(resolve(HOOKS_ROOT, "file"), { recursive: true });

        await safeSymlink(
            resolve(HOOKS_ROOT, "file"),
            resolve(target.path, "hooks"),
            isWindows ? "junction" : "dir"
        );
        return;
    }

    // Standard handling (replace target directory with link)
    // Ensure parent directory exists
    await mkdir(resolve(target.path, ".."), { recursive: true });
    await safeSymlink(HOOKS_ROOT, target.path, isWindows ? "junction" : "dir");
}

/**
 * Sync hooks to all targets
 */
async function sync(): Promise<void> {
    const targets = await getHookTargets();

    if (targets.length === 0) {
        console.log("No hook targets registered.");
        console.log(`Add a target with: ${chalk.cyan("agents hooks target add <name>")}`);
        return;
    }

    // Ensure hooks directory exists
    await mkdir(HOOKS_ROOT, { recursive: true });

    console.log("Syncing hooks to targets...");
    for (const target of targets) {
        try {
            await syncToTarget(target);
            console.log(`  ${target.name}: ${chalk.green("✓")} ${target.path}`);
        } catch (error) {
            console.error(`  ${target.name}: ${chalk.red("✗")} ${error instanceof Error ? error.message : error}`);
        }
    }
    console.log("\nDone.");
}

/**
 * Add a target
 */
async function targetAdd(name: string, path?: string): Promise<void> {
    let absolutePath: string;

    if (path) {
        absolutePath = resolve(path.replace(/^~/, process.env.HOME || process.env.USERPROFILE || ""));
    } else {
        const known = getKnownHookTarget(name);
        if (!known) {
            console.error(chalk.red(`Unknown target: ${name}`));
            console.log(`Run ${chalk.cyan("agents hooks target available")} to see predefined targets.`);
            process.exit(1);
        }
        absolutePath = known.path;
        console.log(`Using predefined path for ${chalk.cyan(known.description)}`);
    }

    console.log(`Adding target: ${chalk.cyan(name)}`);
    await addHookTarget({ name, path: absolutePath });

    // Immediately sync
    await mkdir(HOOKS_ROOT, { recursive: true });
    await syncToTarget({ name, path: absolutePath });
    console.log(chalk.green(`Target "${name}" is now synced.`));
}

/**
 * Show available predefined targets
 */
async function targetAvailable(): Promise<void> {
    const existing = await getHookTargets();
    const existingNames = new Set(existing.map(t => t.name.toLowerCase()));

    console.log();
    console.log(chalk.bold("Available Hook Targets (claude & factory only)"));
    console.log(chalk.dim("─".repeat(50)));

    const table = new Table({
        head: [chalk.bold("Name"), chalk.bold("Description"), chalk.bold("Path"), chalk.bold("Added")],
        style: { head: [], border: [] },
    });

    for (const target of KNOWN_HOOK_TARGETS) {
        const isAdded = existingNames.has(target.name.toLowerCase());
        table.push([target.name, target.description, target.path, isAdded ? chalk.green("✓") : chalk.dim("-")]);
    }

    console.log(table.toString());
    console.log();
}

/**
 * Remove a target
 */
async function targetRemove(name: string): Promise<void> {
    const removed = await removeHookTarget(name);
    if (!removed) throw new Error(`Hook target not found: ${name}`);
    console.log(`Removed target: ${name}`);
    console.log(`Note: Symlink at ${removed.path} was not deleted.`);
}

/**
 * List all targets
 */
async function targetList(): Promise<void> {
    const targets = await getHookTargets();
    if (targets.length === 0) { console.log("No hook targets registered."); return; }

    const table = new Table({
        head: [chalk.bold("Name"), chalk.bold("Path"), chalk.bold("Status")],
        style: { head: [], border: [] },
    });

    for (const target of targets) {
        let status = "missing";
        try {
            const stats = await lstat(target.path);
            status = stats.isSymbolicLink() ? "synced" : "not synced";
        } catch { /* missing */ }
        const statusDisplay = status === "synced" ? chalk.green(status) : chalk.yellow(status);
        table.push([target.name, target.path, statusDisplay]);
    }

    console.log();
    console.log(table.toString());
    console.log();
}

/**
 * Show status
 */
async function status(): Promise<void> {
    console.log();
    console.log(chalk.bold("Hooks Status"));
    console.log(chalk.dim("─".repeat(40)));
    console.log(`Hooks folder: ${HOOKS_ROOT}`);
    console.log(`Edit ${chalk.cyan("~/.agents/hooks/hooks.json")} to configure hooks.`);
    console.log(`Put scripts in ${chalk.cyan("~/.agents/hooks/file/")}`);
    console.log();
    await targetList();
}

// Interactive handlers
async function interactiveTargetAdd(): Promise<void> {
    const existing = await getHookTargets();
    const existingNames = new Set(existing.map(t => t.name.toLowerCase()));
    const available = KNOWN_HOOK_TARGETS.filter(t => !existingNames.has(t.name.toLowerCase()));

    p.intro(chalk.bgCyan(chalk.black(" Add Hook Target ")));

    if (available.length === 0) {
        p.log.warn("All predefined targets (claude, factory) have been added!");
        p.outro("Use 'agents hooks target list' to see your targets.");
        return;
    }

    const name = await p.select({
        message: "Select target:",
        options: available.map(t => ({ value: t.name, label: t.name, hint: t.description })),
    });
    if (p.isCancel(name)) { p.cancel("Cancelled."); process.exit(0); }

    const s = p.spinner();
    s.start("Adding target...");
    try { await targetAdd(name); s.stop("Done!"); }
    catch (e) { s.stop("Failed"); p.log.error(e instanceof Error ? e.message : String(e)); process.exit(1); }
    p.outro(chalk.green("Target added!"));
}

async function interactiveTargetRemove(): Promise<void> {
    const targets = await getHookTargets();
    if (targets.length === 0) { p.log.warn("No targets to remove."); return; }

    p.intro(chalk.bgRed(chalk.white(" Remove Hook Target ")));
    const name = await p.select({
        message: "Which target?",
        options: targets.map(t => ({ value: t.name, label: t.name, hint: t.path })),
    });
    if (p.isCancel(name)) { p.cancel("Cancelled."); process.exit(0); }

    const confirmed = await p.confirm({ message: `Remove "${name}"?` });
    if (p.isCancel(confirmed) || !confirmed) { p.cancel("Cancelled."); process.exit(0); }

    try { await targetRemove(name); p.outro(chalk.green("Removed!")); }
    catch (e) { p.log.error(e instanceof Error ? e.message : String(e)); process.exit(1); }
}

async function interactiveMainMenu(): Promise<void> {
    p.intro(chalk.bgCyan(chalk.black(" Hooks Management ")));

    const action = await p.select({
        message: "What would you like to do?",
        options: [
            { value: "status", label: "View status" },
            { value: "target-add", label: "Add a target" },
            { value: "target-remove", label: "Remove a target" },
            { value: "target-list", label: "List targets" },
            { value: "sync", label: "Sync to all targets" },
        ],
    });
    if (p.isCancel(action)) { p.cancel("Goodbye!"); process.exit(0); }

    console.log();
    switch (action) {
        case "status": await status(); break;
        case "target-add": await interactiveTargetAdd(); break;
        case "target-remove": await interactiveTargetRemove(); break;
        case "target-list": await targetList(); break;
        case "sync": await sync(); break;
    }
}

export async function handleHooksCommand(args: string[]): Promise<void> {
    if (args.includes("--help") || args.includes("-h")) { printHooksHelp(); return; }
    if (args.length === 0) { await interactiveMainMenu(); return; }

    const command = args[0];
    if (!command) return;

    switch (command) {
        case "target": {
            const sub = args[1];
            switch (sub) {
                case "add": {
                    const n = args[2];
                    if (!n) { await interactiveTargetAdd(); return; }
                    await targetAdd(n, args[3]);
                    break;
                }
                case "remove": {
                    const n = args[2];
                    if (!n) { await interactiveTargetRemove(); return; }
                    await targetRemove(n);
                    break;
                }
                case "list": await targetList(); break;
                case "available": await targetAvailable(); break;
                default: console.error(`Unknown: ${sub}`); process.exit(1);
            }
            break;
        }
        case "sync": await sync(); break;
        case "status": await status(); break;
        case "help": printHooksHelp(); break;
        default:
            console.error(chalk.red(`Unknown command: ${command}`));
            process.exit(1);
    }
}
