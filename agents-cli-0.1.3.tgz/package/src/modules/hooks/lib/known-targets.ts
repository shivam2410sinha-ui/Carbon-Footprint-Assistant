import { homedir } from "os";
import { join } from "path";

export interface KnownHookTarget {
    name: string;
    description: string;
    path: string;
}

const home = homedir();

/**
 * Predefined target paths for hook files
 * Based on dotagents - hooks only sync to claude and factory
 */
export const KNOWN_HOOK_TARGETS: KnownHookTarget[] = [
    {
        name: "claude",
        description: "Claude Code / Claude Desktop",
        path: join(home, ".claude", "hooks"),
    },
    {
        name: "cursor",
        description: "Cursor IDE",
        path: join(home, ".cursor"),
    },
    {
        name: "factory",
        description: "Factory",
        path: join(home, ".factory", "hooks"),
    },
];

/**
 * Get a known hook target by name
 */
export function getKnownHookTarget(name: string): KnownHookTarget | undefined {
    return KNOWN_HOOK_TARGETS.find(t => t.name.toLowerCase() === name.toLowerCase());
}

/**
 * Get all known hook target names
 */
export function getKnownHookTargetNames(): string[] {
    return KNOWN_HOOK_TARGETS.map(t => t.name);
}
