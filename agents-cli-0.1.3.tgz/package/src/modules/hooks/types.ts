/**
 * Hook target - where hooks are synced to
 */
export interface HookTarget {
    name: string;
    path: string;
}

/**
 * Hooks module configuration (simplified - no sources, just targets)
 */
export interface HooksConfig {
    targets: HookTarget[];
}
