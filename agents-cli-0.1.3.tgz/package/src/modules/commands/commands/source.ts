import { $ } from "bun";
import { resolve } from "path";
import { rm, cp, mkdir, readdir } from "fs/promises";
import chalk from "chalk";
import Table from "cli-table3";
import { addCommandSource, removeCommandSource, getCommandSources } from "../../../lib/config.ts";
import { getCommandSourcePath, COMMANDS_SOURCES } from "../../../lib/paths.ts";
import { directoryExists } from "../../../lib/hash.ts";
import { parseGitUrl, getDefaultSkillName, getLocalSkillName } from "../../skills/lib/git-url.ts";
import { rebuildStore } from "./sync.ts";

/**
 * Add a source (remote or local)
 */
export async function sourceAdd(pathOrUrl: string, type: "remote" | "local", customName?: string): Promise<void> {
    if (type === "remote") {
        await addRemoteSource(pathOrUrl, customName);
    } else {
        await addLocalSource(pathOrUrl, customName);
    }

    // Rebuild store after adding source
    await rebuildStore();
}

/**
 * Add a remote Git repository as a source
 */
async function addRemoteSource(url: string, customName?: string): Promise<void> {
    const parsed = parseGitUrl(url);

    if (!parsed) {
        throw new Error(`Invalid Git URL: ${url}`);
    }

    const defaultName = getDefaultSkillName(parsed);
    const sourceName = customName || defaultName;
    const targetPath = getCommandSourcePath(sourceName);
    const cloneUrl = parsed.cloneUrl;
    const branch = parsed.branch || "main";

    console.log(`Adding remote source: ${url}`);
    console.log(`Source name: ${chalk.cyan(sourceName)}`);

    if (await directoryExists(targetPath)) {
        throw new Error(`Source "${sourceName}" already exists. Remove it first or use --name to specify a different name.`);
    }

    await mkdir(COMMANDS_SOURCES, { recursive: true });

    console.log("Cloning repository...");

    try {
        if (parsed.subdir) {
            const tempPath = `${targetPath}_temp`;

            await $`git clone --filter=blob:none --no-checkout --depth 1 --branch ${branch} ${cloneUrl} ${tempPath}`.quiet();
            await $`git -C ${tempPath} sparse-checkout init --cone`.quiet();
            await $`git -C ${tempPath} sparse-checkout set ${parsed.subdir}`.quiet();
            await $`git -C ${tempPath} checkout`.quiet();

            const subdirFullPath = `${tempPath}/${parsed.subdir}`;
            await cp(subdirFullPath, targetPath, { recursive: true });
            await rm(tempPath, { recursive: true, force: true });
        } else {
            await $`git clone --depth 1 --branch ${branch} ${cloneUrl} ${targetPath}`.quiet();
            await rm(`${targetPath}/.git`, { recursive: true, force: true });
        }
    } catch (error) {
        await rm(targetPath, { recursive: true, force: true });
        await rm(`${targetPath}_temp`, { recursive: true, force: true });
        throw new Error(`Failed to clone repository: ${error}`);
    }

    await addCommandSource({
        type: "remote",
        url,
        name: sourceName,
    });

    console.log(chalk.green(`Successfully added command source: ${sourceName}`));
}

/**
 * Add a local folder as a source
 */
async function addLocalSource(folderPath: string, customName?: string): Promise<void> {
    const absolutePath = resolve(folderPath);

    if (!(await directoryExists(absolutePath))) {
        throw new Error(`Local folder does not exist: ${absolutePath}`);
    }

    const defaultName = getLocalSkillName(absolutePath);
    const sourceName = customName || defaultName;
    const targetPath = getCommandSourcePath(sourceName);

    console.log(`Adding local source: ${absolutePath}`);
    console.log(`Source name: ${chalk.cyan(sourceName)}`);

    if (await directoryExists(targetPath)) {
        throw new Error(`Source "${sourceName}" already exists. Remove it first or use --name to specify a different name.`);
    }

    await mkdir(COMMANDS_SOURCES, { recursive: true });

    console.log("Copying files...");
    await cp(absolutePath, targetPath, { recursive: true });

    await addCommandSource({
        type: "local",
        path: absolutePath,
        name: sourceName,
    });

    console.log(chalk.green(`Successfully added command source: ${sourceName}`));
}

/**
 * Remove a source by name
 */
export async function sourceRemove(name: string): Promise<void> {
    const removed = await removeCommandSource(name);

    if (!removed) {
        throw new Error(`Command source not found: ${name}`);
    }

    const targetPath = getCommandSourcePath(name);
    await rm(targetPath, { recursive: true, force: true });

    // Rebuild store after removing source
    await rebuildStore();

    console.log(chalk.green(`Removed command source: ${name}`));
}

/**
 * List all sources
 */
export async function sourceList(): Promise<void> {
    const sources = await getCommandSources();

    if (sources.length === 0) {
        console.log("No command sources registered.");
        console.log(`Add a source with: ${chalk.cyan("agents commands source add <path> --local")}`);
        return;
    }

    const table = new Table({
        head: [
            chalk.bold("Source"),
            chalk.bold("Type"),
            chalk.bold("Origin"),
            chalk.bold("Files"),
        ],
        style: { head: [], border: [] },
    });

    for (const source of sources) {
        const sourcePath = getCommandSourcePath(source.name);
        let fileCount = 0;

        if (await directoryExists(sourcePath)) {
            try {
                const files = await readdir(sourcePath);
                fileCount = files.filter(f => f.endsWith(".md")).length;
            } catch {
                // Ignore
            }
        }

        table.push([
            source.name,
            source.type,
            source.url || source.path || "",
            `${fileCount} .md`,
        ]);
    }

    console.log();
    console.log(table.toString());
    console.log();
}
