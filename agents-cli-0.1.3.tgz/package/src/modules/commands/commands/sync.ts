import { readdir, symlink, rm, lstat, mkdir } from "fs/promises";
import { join } from "path";
import chalk from "chalk";
import { getCommandTargets } from "../../../lib/config.ts";
import { COMMANDS_SOURCES, COMMANDS_STORE, COMMANDS_ALIASES } from "../../../lib/paths.ts";
import { directoryExists } from "../../../lib/hash.ts";
import type { CommandFile, AliasMap, CommandTarget } from "../types.ts";

/**
 * Collect all .md files from all sources
 */
async function collectAllCommandFiles(): Promise<CommandFile[]> {
    const files: CommandFile[] = [];

    if (!(await directoryExists(COMMANDS_SOURCES))) {
        return files;
    }

    try {
        const sources = await readdir(COMMANDS_SOURCES, { withFileTypes: true });

        for (const source of sources) {
            if (!source.isDirectory()) continue;

            const sourcePath = join(COMMANDS_SOURCES, source.name);
            const sourceFiles = await readdir(sourcePath);

            for (const file of sourceFiles) {
                if (file.endsWith(".md")) {
                    files.push({
                        source: source.name,
                        filename: file,
                        fullPath: join(sourcePath, file),
                    });
                }
            }
        }
    } catch {
        // Sources directory doesn't exist or can't be read
    }

    return files;
}

/**
 * Resolve filename conflicts by aliasing
 * First source (by order in config) wins the original name
 */
function resolveConflicts(files: CommandFile[]): {
    resolved: Map<string, string>;  // targetFilename -> sourcePath
    aliases: AliasMap;
} {
    const resolved = new Map<string, string>();
    const aliases: AliasMap = {};
    const seenFilenames = new Map<string, string>();  // filename -> source that owns it

    for (const file of files) {
        const existingOwner = seenFilenames.get(file.filename);

        if (!existingOwner) {
            // First occurrence - use original filename
            seenFilenames.set(file.filename, file.source);
            resolved.set(file.filename, file.fullPath);
        } else {
            // Conflict - alias with source prefix
            const aliasedName = `${file.source}--${file.filename}`;
            resolved.set(aliasedName, file.fullPath);
            aliases[aliasedName] = file.filename;
        }
    }

    return { resolved, aliases };
}

/**
 * Save alias mapping to file
 */
async function saveAliases(aliases: AliasMap): Promise<void> {
    await Bun.write(COMMANDS_ALIASES, JSON.stringify(aliases, null, 2));
}

/**
 * Read alias mapping from file
 */
export async function readAliases(): Promise<AliasMap> {
    const file = Bun.file(COMMANDS_ALIASES);
    if (!(await file.exists())) {
        return {};
    }
    try {
        return await file.json();
    } catch {
        return {};
    }
}

/**
 * Create a file symlink
 */
async function createFileSymlink(source: string, target: string): Promise<void> {
    try {
        const stats = await lstat(target);
        if (stats.isSymbolicLink() || stats.isFile()) {
            await rm(target, { force: true });
        }
    } catch {
        // Target doesn't exist
    }

    // On Windows, use 'file' type for file symlinks
    await symlink(source, target, "file");
}

/**
 * Rebuild the store with flattened symlinks
 */
export async function rebuildStore(): Promise<void> {
    // Ensure store directory exists and is empty
    await rm(COMMANDS_STORE, { recursive: true, force: true });
    await mkdir(COMMANDS_STORE, { recursive: true });

    const files = await collectAllCommandFiles();

    if (files.length === 0) {
        return;
    }

    const { resolved, aliases } = resolveConflicts(files);

    // Create symlinks in store
    for (const [targetFilename, sourcePath] of resolved) {
        const targetPath = join(COMMANDS_STORE, targetFilename);
        await createFileSymlink(sourcePath, targetPath);
    }

    // Save aliases
    await saveAliases(aliases);
}

/**
 * Create a directory symlink (junction on Windows)
 */
async function createDirSymlink(source: string, target: string): Promise<void> {
    const isWindows = process.platform === "win32";

    try {
        const stats = await lstat(target);
        if (stats.isSymbolicLink() || stats.isDirectory()) {
            await rm(target, { recursive: true, force: true });
        }
    } catch {
        // Target doesn't exist
    }

    await symlink(source, target, isWindows ? "junction" : "dir");
}

/**
 * Sync store to a single target
 */
export async function syncToTarget(target: CommandTarget): Promise<void> {
    // Rebuild store first
    await rebuildStore();

    // Symlink store to target
    await createDirSymlink(COMMANDS_STORE, target.path);

    const files = await collectAllCommandFiles();
    console.log(`  ${target.name}: Synced ${files.length} command(s) via store symlink`);
}

/**
 * Sync store to all targets
 */
export async function sync(): Promise<void> {
    const targets = await getCommandTargets();

    if (targets.length === 0) {
        console.log("No command targets registered.");
        console.log(`Add a target with: ${chalk.cyan("agents commands target add <name>")}`);
        return;
    }

    // Rebuild store
    console.log("Rebuilding command store...");
    await rebuildStore();

    const files = await collectAllCommandFiles();
    const aliases = await readAliases();
    const aliasCount = Object.keys(aliases).length;

    console.log(`  ${files.length} command(s), ${aliasCount} alias(es)`);
    console.log();

    console.log("Syncing to targets...");
    for (const target of targets) {
        try {
            await createDirSymlink(COMMANDS_STORE, target.path);
            console.log(`  ${target.name}: ${chalk.green("✓")} ${target.path}`);
        } catch (error) {
            console.error(`  ${target.name}: ${chalk.red("✗")} ${error instanceof Error ? error.message : error}`);
        }
    }

    console.log();
    console.log("Sync complete.");
}
