import { $ } from "bun";
import { rm, cp, mkdir } from "fs/promises";
import chalk from "chalk";
import { getCommandSources } from "../../../lib/config.ts";
import { getCommandSourcePath, COMMANDS_SOURCES } from "../../../lib/paths.ts";
import { directoryExists } from "../../../lib/hash.ts";
import { parseGitUrl } from "../../skills/lib/git-url.ts";
import { rebuildStore, sync } from "./sync.ts";

/**
 * Update all command sources from their origins
 */
export async function update(): Promise<void> {
    const sources = await getCommandSources();

    if (sources.length === 0) {
        console.log("No command sources registered.");
        console.log(`Add a source with: ${chalk.cyan("agents commands source add <path> --local")}`);
        return;
    }

    console.log("Updating command sources...\n");

    let updated = 0;
    let failed = 0;

    for (const source of sources) {
        const sourcePath = getCommandSourcePath(source.name);

        try {
            if (source.type === "remote" && source.url) {
                console.log(`  ${source.name}: Updating from remote...`);

                const parsed = parseGitUrl(source.url);
                if (!parsed) {
                    console.log(`  ${source.name}: ${chalk.red("Invalid URL")}`);
                    failed++;
                    continue;
                }

                const branch = parsed.branch || "main";
                const cloneUrl = parsed.cloneUrl;

                await rm(sourcePath, { recursive: true, force: true });
                await mkdir(COMMANDS_SOURCES, { recursive: true });

                if (parsed.subdir) {
                    const tempPath = `${sourcePath}_temp`;

                    await $`git clone --filter=blob:none --no-checkout --depth 1 --branch ${branch} ${cloneUrl} ${tempPath}`.quiet();
                    await $`git -C ${tempPath} sparse-checkout init --cone`.quiet();
                    await $`git -C ${tempPath} sparse-checkout set ${parsed.subdir}`.quiet();
                    await $`git -C ${tempPath} checkout`.quiet();

                    const subdirFullPath = `${tempPath}/${parsed.subdir}`;
                    await cp(subdirFullPath, sourcePath, { recursive: true });
                    await rm(tempPath, { recursive: true, force: true });
                } else {
                    await $`git clone --depth 1 --branch ${branch} ${cloneUrl} ${sourcePath}`.quiet();
                    await rm(`${sourcePath}/.git`, { recursive: true, force: true });
                }

                console.log(`  ${source.name}: ${chalk.green("Updated")}`);
                updated++;

            } else if (source.type === "local" && source.path) {
                console.log(`  ${source.name}: Syncing from local...`);

                if (!(await directoryExists(source.path))) {
                    console.log(`  ${source.name}: ${chalk.red("Source folder missing")}`);
                    failed++;
                    continue;
                }

                await rm(sourcePath, { recursive: true, force: true });
                await cp(source.path, sourcePath, { recursive: true });

                console.log(`  ${source.name}: ${chalk.green("Updated")}`);
                updated++;
            }
        } catch (error) {
            console.log(`  ${source.name}: ${chalk.red(`Failed - ${error instanceof Error ? error.message : error}`)}`);
            failed++;
        }
    }

    console.log();
    console.log(`Updated: ${updated}, Failed: ${failed}`);

    if (updated > 0) {
        console.log("\nRebuilding store and syncing targets...");
        await sync();
    }
}
