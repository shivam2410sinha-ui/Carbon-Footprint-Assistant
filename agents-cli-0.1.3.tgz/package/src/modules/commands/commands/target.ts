import { resolve } from "path";
import { mkdir, lstat, rm, symlink } from "fs/promises";
import chalk from "chalk";
import Table from "cli-table3";
import { addCommandTarget, removeCommandTarget, getCommandTargets } from "../../../lib/config.ts";
import { COMMANDS_STORE } from "../../../lib/paths.ts";
import { directoryExists } from "../../../lib/hash.ts";
import { getKnownCommandTarget, KNOWN_COMMAND_TARGETS } from "../lib/known-targets.ts";
import { rebuildStore } from "./sync.ts";
import type { CommandTarget } from "../types.ts";

/**
 * Add a target directory
 */
export async function targetAdd(name: string, path?: string): Promise<void> {
    let absolutePath: string;

    if (path) {
        absolutePath = resolve(path.replace(/^~/, process.env.HOME || process.env.USERPROFILE || ""));
    } else {
        const known = getKnownCommandTarget(name);
        if (!known) {
            console.error(chalk.red(`Unknown target: ${name}`));
            console.log(`\nRun ${chalk.cyan("agents commands target available")} to see predefined targets.`);
            console.log(`Or specify a custom path: ${chalk.cyan(`agents commands target add ${name} <path>`)}`);
            process.exit(1);
        }
        absolutePath = known.path;
        console.log(`Using predefined path for ${chalk.cyan(known.description)}`);
    }

    console.log(`Adding target: ${chalk.cyan(name)}`);
    console.log(`Path: ${absolutePath}`);

    // Add to config
    await addCommandTarget({
        name,
        path: absolutePath,
    });

    // Rebuild store and sync
    console.log("Rebuilding store and syncing...");
    await rebuildStore();

    // Create symlink to store
    const isWindows = process.platform === "win32";
    try {
        const stats = await lstat(absolutePath);
        if (stats.isSymbolicLink() || stats.isDirectory()) {
            await rm(absolutePath, { recursive: true, force: true });
        }
    } catch {
        // Doesn't exist
    }

    await symlink(COMMANDS_STORE, absolutePath, isWindows ? "junction" : "dir");

    console.log(chalk.green(`Target "${name}" is now synced to store.`));
}

/**
 * Show available predefined targets
 */
export async function targetAvailable(): Promise<void> {
    const existingTargets = await getCommandTargets();
    const existingNames = new Set(existingTargets.map(t => t.name.toLowerCase()));

    console.log();
    console.log(chalk.bold("Available Predefined Command Targets"));
    console.log(chalk.dim("─".repeat(60)));
    console.log();

    const table = new Table({
        head: [
            chalk.bold("Name"),
            chalk.bold("Description"),
            chalk.bold("Path"),
            chalk.bold("Added"),
        ],
        style: { head: [], border: [] },
    });

    for (const target of KNOWN_COMMAND_TARGETS) {
        const isAdded = existingNames.has(target.name.toLowerCase());
        const addedStatus = isAdded ? chalk.green("✓") : chalk.dim("-");

        table.push([
            target.name,
            target.description,
            target.path,
            addedStatus,
        ]);
    }

    console.log(table.toString());
    console.log();
    console.log(chalk.bold("Usage:"));
    console.log(`  ${chalk.cyan("agents commands target add <name>")}              Add a predefined target`);
    console.log(`  ${chalk.cyan("agents commands target add <name> <path>")}       Add a custom target`);
    console.log();
}

/**
 * Remove a target by name
 */
export async function targetRemove(name: string): Promise<void> {
    const removed = await removeCommandTarget(name);

    if (!removed) {
        throw new Error(`Command target not found: ${name}`);
    }

    console.log(`Removed target: ${name}`);
    console.log(`Note: Symlink at ${removed.path} was not deleted.`);
}

/**
 * Check if a target is synced
 */
async function getTargetSyncStatus(target: CommandTarget): Promise<"synced" | "not synced" | "target missing"> {
    try {
        const stats = await lstat(target.path);
        if (stats.isSymbolicLink()) {
            return "synced";
        }
        return "not synced";
    } catch {
        return "target missing";
    }
}

/**
 * List all targets with sync status
 */
export async function targetList(): Promise<void> {
    const targets = await getCommandTargets();

    if (targets.length === 0) {
        console.log("No command targets registered.");
        console.log(`Add a target with: ${chalk.cyan("agents commands target add <name>")}`);
        return;
    }

    const table = new Table({
        head: [
            chalk.bold("Name"),
            chalk.bold("Path"),
            chalk.bold("Status"),
        ],
        style: { head: [], border: [] },
    });

    for (const target of targets) {
        const status = await getTargetSyncStatus(target);
        let statusDisplay: string;

        if (status === "synced") {
            statusDisplay = chalk.green("synced");
        } else if (status === "not synced") {
            statusDisplay = chalk.yellow("not synced");
        } else {
            statusDisplay = chalk.red("missing");
        }

        table.push([
            target.name,
            target.path,
            statusDisplay,
        ]);
    }

    console.log();
    console.log(table.toString());
    console.log();
}
