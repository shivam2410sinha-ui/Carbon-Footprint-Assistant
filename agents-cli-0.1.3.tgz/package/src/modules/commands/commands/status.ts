import { readdir } from "fs/promises";
import chalk from "chalk";
import Table from "cli-table3";
import { getCommandSources, getCommandTargets } from "../../../lib/config.ts";
import { COMMANDS_SOURCES, COMMANDS_STORE, getCommandSourcePath } from "../../../lib/paths.ts";
import { directoryExists } from "../../../lib/hash.ts";
import { readAliases } from "./sync.ts";

/**
 * Show overview of commands, targets & sync state
 */
export async function status(): Promise<void> {
    const sources = await getCommandSources();
    const targets = await getCommandTargets();
    const aliases = await readAliases();

    console.log();
    console.log(chalk.bold("Commands CLI Status"));
    console.log(chalk.dim("─".repeat(50)));
    console.log();

    // Sources summary
    console.log(chalk.bold("Sources:"));
    if (sources.length === 0) {
        console.log(chalk.dim("  No sources registered"));
    } else {
        const table = new Table({
            head: [chalk.bold("Name"), chalk.bold("Type"), chalk.bold("Files")],
            style: { head: [], border: [] },
        });

        for (const source of sources) {
            const sourcePath = getCommandSourcePath(source.name);
            let fileCount = 0;

            if (await directoryExists(sourcePath)) {
                try {
                    const files = await readdir(sourcePath);
                    fileCount = files.filter(f => f.endsWith(".md")).length;
                } catch {
                    // Ignore
                }
            }

            table.push([
                source.name,
                source.type,
                `${fileCount} .md`,
            ]);
        }

        console.log(table.toString());
    }

    console.log();

    // Targets summary
    console.log(chalk.bold("Targets:"));
    if (targets.length === 0) {
        console.log(chalk.dim("  No targets registered"));
    } else {
        const table = new Table({
            head: [chalk.bold("Name"), chalk.bold("Path")],
            style: { head: [], border: [] },
        });

        for (const target of targets) {
            table.push([target.name, target.path]);
        }

        console.log(table.toString());
    }

    console.log();

    // Store info
    console.log(chalk.bold("Store:"));
    const storeExists = await directoryExists(COMMANDS_STORE);
    if (storeExists) {
        try {
            const storeContents = await readdir(COMMANDS_STORE);
            const mdFiles = storeContents.filter(f => f.endsWith(".md"));
            console.log(`  ${mdFiles.length} command(s) in store`);

            const aliasCount = Object.keys(aliases).length;
            if (aliasCount > 0) {
                console.log(`  ${aliasCount} aliased file(s) due to conflicts`);
            }
        } catch {
            console.log(chalk.dim("  Store empty"));
        }
    } else {
        console.log(chalk.dim("  Store not created yet"));
    }

    console.log();
}
