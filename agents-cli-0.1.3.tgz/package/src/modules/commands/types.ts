/**
 * Command source - where commands originate from
 */
export interface CommandSource {
    /** Type of source */
    type: "remote" | "local";
    /** Git URL for remote sources */
    url?: string;
    /** Absolute path for local sources */
    path?: string;
    /** Source name (folder name in sources/) */
    name: string;
}

/**
 * Command target - where commands are synced to
 */
export interface CommandTarget {
    /** User-friendly name (e.g., "cursor") */
    name: string;
    /** Absolute path to target directory */
    path: string;
}

/**
 * Commands module configuration
 */
export interface CommandsConfig {
    sources: CommandSource[];
    targets: CommandTarget[];
}

/**
 * Alias mapping for conflict resolution
 * Key: aliased filename (e.g., "source--filename.md")
 * Value: original filename (e.g., "filename.md")
 */
export type AliasMap = Record<string, string>;

/**
 * File info for sync operations
 */
export interface CommandFile {
    /** Source name */
    source: string;
    /** Original filename */
    filename: string;
    /** Full path to file */
    fullPath: string;
}
