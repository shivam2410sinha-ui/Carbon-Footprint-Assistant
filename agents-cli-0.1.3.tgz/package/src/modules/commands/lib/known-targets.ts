import { homedir } from "os";
import { join } from "path";

export interface KnownCommandTarget {
    name: string;
    description: string;
    path: string;
}

const home = homedir();

/**
 * Predefined target paths for command files
 */
export const KNOWN_COMMAND_TARGETS: KnownCommandTarget[] = [
    {
        name: "claude",
        description: "Claude Code / Claude Desktop",
        path: join(home, ".claude", "commands"),
    },
    {
        name: "cursor",
        description: "Cursor IDE",
        path: join(home, ".cursor", "commands"),
    },
    {
        name: "gemini",
        description: "Gemini CLI",
        path: join(home, ".gemini", "commands"),
    },
    {
        name: "factory",
        description: "Factory",
        path: join(home, ".factory", "commands"),
    },
    {
        name: "codex",
        description: "Codex (uses prompts folder)",
        path: join(home, ".codex", "prompts"),
    },
    {
        name: "opencode",
        description: "OpenCode CLI",
        path: join(home, ".config", "opencode", "commands"),
    },
    {
        name: "windsurf",
        description: "Windsurf IDE",
        path: join(home, ".windsurf", "commands"),
    },
    {
        name: "antigravity",
        description: "Antigravity",
        path: join(home, ".gemini", "antigravity", "commands"),
    },
];

/**
 * Get a known command target by name
 */
export function getKnownCommandTarget(name: string): KnownCommandTarget | undefined {
    return KNOWN_COMMAND_TARGETS.find(t => t.name.toLowerCase() === name.toLowerCase());
}

/**
 * Get all known command target names
 */
export function getKnownCommandTargetNames(): string[] {
    return KNOWN_COMMAND_TARGETS.map(t => t.name);
}
