import * as p from "@clack/prompts";
import chalk from "chalk";
import { sourceAdd, sourceRemove, sourceList } from "./commands/source.ts";
import { targetAdd, targetRemove, targetList, targetAvailable } from "./commands/target.ts";
import { sync } from "./commands/sync.ts";
import { update } from "./commands/update.ts";
import { status } from "./commands/status.ts";
import { getCommandSources, getCommandTargets } from "../../lib/config.ts";
import { KNOWN_COMMAND_TARGETS } from "./lib/known-targets.ts";

/**
 * Print help for the commands module
 */
function printCommandsHelp() {
    console.log(`
${chalk.bold("agents commands")} - Manage command files across all your agent tools

${chalk.bold("USAGE")}
  ${chalk.cyan("agents commands")} <command> [options]

${chalk.bold("COMMANDS")}
  ${chalk.cyan("status")}                        Show overview of sources, targets & store

  ${chalk.bold("Source Management")}
  ${chalk.cyan("source list")}                   List all registered sources
  ${chalk.cyan("source add")} [url|path]         Add a source (interactive if no args)
  ${chalk.cyan("source remove")} [name]          Remove a source (interactive if no args)

  ${chalk.bold("Target Management")}
  ${chalk.cyan("target list")}                   List all targets with sync status
  ${chalk.cyan("target available")}              Show predefined targets
  ${chalk.cyan("target add")} [name]             Add a target (interactive if no args)
  ${chalk.cyan("target remove")} [name]          Remove a target (interactive if no args)

  ${chalk.bold("Synchronization")}
  ${chalk.cyan("sync")}                          Rebuild store and sync to all targets
  ${chalk.cyan("update")}                        Refresh all sources from origin

${chalk.bold("OPTIONS")}
  ${chalk.cyan("--name <name>")}                 Custom name for the source
  ${chalk.cyan("--remote")}                      Source is a Git repository
  ${chalk.cyan("--local")}                       Source is a local folder
  ${chalk.cyan("--help, -h")}                    Show this help message

${chalk.bold("EXAMPLES")}
  ${chalk.dim("# Add a local commands folder")}
  ${chalk.cyan("agents commands source add")} ./my-commands --local

  ${chalk.dim("# Add predefined targets")}
  ${chalk.cyan("agents commands target add")} cursor
  ${chalk.cyan("agents commands target add")} claude

  ${chalk.dim("# Sync to all targets")}
  ${chalk.cyan("agents commands sync")}
`);
}

/**
 * Interactive source add
 */
async function interactiveSourceAdd(): Promise<void> {
    p.intro(chalk.bgCyan(chalk.black(" Add Command Source ")));

    const sourceType = await p.select({
        message: "What type of source?",
        options: [
            { value: "local", label: "Local (folder on disk)" },
            { value: "remote", label: "Remote (Git repository)" },
        ],
    });

    if (p.isCancel(sourceType)) {
        p.cancel("Operation cancelled.");
        process.exit(0);
    }

    let pathOrUrl: string | symbol;
    if (sourceType === "remote") {
        pathOrUrl = await p.text({
            message: "Enter the Git repository URL:",
            placeholder: "https://github.com/user/commands",
            validate: (value) => {
                if (!value) return "URL is required";
                if (!value.startsWith("http") && !value.startsWith("git@")) {
                    return "Please enter a valid Git URL";
                }
            },
        });
    } else {
        pathOrUrl = await p.text({
            message: "Enter the local folder path:",
            placeholder: "./my-commands",
            validate: (value) => {
                if (!value) return "Path is required";
            },
        });
    }

    if (p.isCancel(pathOrUrl)) {
        p.cancel("Operation cancelled.");
        process.exit(0);
    }

    const customName = await p.text({
        message: "Custom source name (leave empty for default):",
        placeholder: "my-commands",
    });

    if (p.isCancel(customName)) {
        p.cancel("Operation cancelled.");
        process.exit(0);
    }

    const s = p.spinner();
    s.start("Adding source...");

    try {
        await sourceAdd(pathOrUrl, sourceType as "remote" | "local", customName || undefined);
        s.stop("Source added successfully!");
    } catch (error) {
        s.stop("Failed to add source");
        p.log.error(error instanceof Error ? error.message : String(error));
        process.exit(1);
    }

    p.outro(chalk.green("Done!"));
}

/**
 * Interactive source remove
 */
async function interactiveSourceRemove(): Promise<void> {
    const sources = await getCommandSources();

    if (sources.length === 0) {
        p.log.warn("No sources registered to remove.");
        return;
    }

    p.intro(chalk.bgRed(chalk.white(" Remove Command Source ")));

    const sourceName = await p.select({
        message: "Which source do you want to remove?",
        options: sources.map((s) => ({
            value: s.name,
            label: s.name,
            hint: s.type === "remote" ? s.url : s.path,
        })),
    });

    if (p.isCancel(sourceName)) {
        p.cancel("Operation cancelled.");
        process.exit(0);
    }

    const confirmed = await p.confirm({
        message: `Are you sure you want to remove "${sourceName}"?`,
    });

    if (p.isCancel(confirmed) || !confirmed) {
        p.cancel("Operation cancelled.");
        process.exit(0);
    }

    try {
        await sourceRemove(sourceName);
        p.outro(chalk.green("Source removed!"));
    } catch (error) {
        p.log.error(error instanceof Error ? error.message : String(error));
        process.exit(1);
    }
}

/**
 * Interactive target add
 */
async function interactiveTargetAdd(): Promise<void> {
    const existingTargets = await getCommandTargets();
    const existingNames = new Set(existingTargets.map((t) => t.name.toLowerCase()));

    const availableTargets = KNOWN_COMMAND_TARGETS.filter(
        (t) => !existingNames.has(t.name.toLowerCase())
    );

    p.intro(chalk.bgCyan(chalk.black(" Add Command Target ")));

    const targetType = await p.select({
        message: "What type of target?",
        options: [
            { value: "predefined", label: "Predefined target (Cursor, Claude, etc.)" },
            { value: "custom", label: "Custom path" },
        ],
    });

    if (p.isCancel(targetType)) {
        p.cancel("Operation cancelled.");
        process.exit(0);
    }

    let targetName: string | symbol;
    let targetPath: string | undefined;

    if (targetType === "predefined") {
        if (availableTargets.length === 0) {
            p.log.warn("All predefined targets have already been added!");
            p.outro("Use 'agents commands target list' to see your targets.");
            return;
        }

        targetName = await p.select({
            message: "Select a target:",
            options: availableTargets.map((t) => ({
                value: t.name,
                label: t.name,
                hint: t.description,
            })),
        });
    } else {
        targetName = await p.text({
            message: "Enter a name for this target:",
            placeholder: "my-tool",
            validate: (value) => {
                if (!value) return "Name is required";
                if (existingNames.has(value.toLowerCase())) {
                    return "A target with this name already exists";
                }
            },
        });

        if (p.isCancel(targetName)) {
            p.cancel("Operation cancelled.");
            process.exit(0);
        }

        const pathInput = await p.text({
            message: "Enter the target path:",
            placeholder: "~/.my-tool/commands",
            validate: (value) => {
                if (!value) return "Path is required";
            },
        });

        if (p.isCancel(pathInput)) {
            p.cancel("Operation cancelled.");
            process.exit(0);
        }

        targetPath = pathInput;
    }

    if (p.isCancel(targetName)) {
        p.cancel("Operation cancelled.");
        process.exit(0);
    }

    const s = p.spinner();
    s.start("Adding target and syncing...");

    try {
        await targetAdd(targetName, targetPath);
        s.stop("Target added and synced!");
    } catch (error) {
        s.stop("Failed to add target");
        p.log.error(error instanceof Error ? error.message : String(error));
        process.exit(1);
    }

    p.outro(chalk.green("Done!"));
}

/**
 * Interactive target remove
 */
async function interactiveTargetRemove(): Promise<void> {
    const targets = await getCommandTargets();

    if (targets.length === 0) {
        p.log.warn("No targets registered to remove.");
        return;
    }

    p.intro(chalk.bgRed(chalk.white(" Remove Command Target ")));

    const targetName = await p.select({
        message: "Which target do you want to remove?",
        options: targets.map((t) => ({
            value: t.name,
            label: t.name,
            hint: t.path,
        })),
    });

    if (p.isCancel(targetName)) {
        p.cancel("Operation cancelled.");
        process.exit(0);
    }

    const confirmed = await p.confirm({
        message: `Are you sure you want to remove "${targetName}"?`,
    });

    if (p.isCancel(confirmed) || !confirmed) {
        p.cancel("Operation cancelled.");
        process.exit(0);
    }

    try {
        await targetRemove(targetName);
        p.outro(chalk.green("Target removed!"));
    } catch (error) {
        p.log.error(error instanceof Error ? error.message : String(error));
        process.exit(1);
    }
}

/**
 * Interactive main menu
 */
async function interactiveMainMenu(): Promise<void> {
    p.intro(chalk.bgCyan(chalk.black(" Commands Management ")));

    const action = await p.select({
        message: "What would you like to do?",
        options: [
            { value: "status", label: "View status", hint: "Overview of sources & targets" },
            { value: "source-add", label: "Add a source", hint: "From Git repo or local folder" },
            { value: "source-remove", label: "Remove a source" },
            { value: "source-list", label: "List sources" },
            { value: "target-add", label: "Add a target", hint: "Cursor, Claude, etc." },
            { value: "target-remove", label: "Remove a target" },
            { value: "target-list", label: "List targets" },
            { value: "sync", label: "Sync all targets", hint: "Rebuild store and sync" },
            { value: "update", label: "Update all sources", hint: "Refresh from origins" },
        ],
    });

    if (p.isCancel(action)) {
        p.cancel("Goodbye!");
        process.exit(0);
    }

    console.log();

    switch (action) {
        case "status":
            await status();
            break;
        case "source-add":
            await interactiveSourceAdd();
            break;
        case "source-remove":
            await interactiveSourceRemove();
            break;
        case "source-list":
            await sourceList();
            break;
        case "target-add":
            await interactiveTargetAdd();
            break;
        case "target-remove":
            await interactiveTargetRemove();
            break;
        case "target-list":
            await targetList();
            break;
        case "sync":
            await sync();
            break;
        case "update":
            await update();
            break;
    }
}

/**
 * Handle commands module
 */
export async function handleCommandsCommand(args: string[]): Promise<void> {
    if (args.includes("--help") || args.includes("-h")) {
        printCommandsHelp();
        return;
    }

    if (args.length === 0) {
        await interactiveMainMenu();
        return;
    }

    const command = args[0];
    if (!command) return;
    const subcommand = args[1];

    switch (command) {
        case "source":
            await handleSourceCommand(subcommand, args.slice(2));
            break;

        case "target":
            await handleTargetCommand(subcommand, args.slice(2));
            break;

        case "sync":
            await sync();
            break;

        case "update":
            await update();
            break;

        case "status":
            await status();
            break;

        case "help":
            printCommandsHelp();
            break;

        default:
            console.error(chalk.red(`Unknown command: ${command}`));
            console.log(`Run ${chalk.cyan("agents commands --help")} for usage.`);
            process.exit(1);
    }
}

async function handleSourceCommand(subcommand: string | undefined, args: string[]) {
    switch (subcommand) {
        case "add": {
            if (args.length === 0 || (!args.includes("--remote") && !args.includes("--local"))) {
                await interactiveSourceAdd();
                return;
            }

            const nonFlagArgs = args.filter((a) => !a.startsWith("--"));
            const pathOrUrl = nonFlagArgs[0];
            const isRemote = args.includes("--remote");
            const isLocal = args.includes("--local");

            const nameIndex = args.findIndex((a) => a === "--name");
            const customName = nameIndex !== -1 ? args[nameIndex + 1] : undefined;

            if (!pathOrUrl) {
                console.error("Missing path or URL");
                process.exit(1);
            }

            if (isRemote && isLocal) {
                console.error("Cannot specify both --remote and --local");
                process.exit(1);
            }

            await sourceAdd(pathOrUrl, isRemote ? "remote" : "local", customName || undefined);
            break;
        }

        case "remove": {
            const name = args[0];
            if (!name) {
                await interactiveSourceRemove();
                return;
            }
            await sourceRemove(name);
            break;
        }

        case "list":
            await sourceList();
            break;

        default:
            console.error(`Unknown source subcommand: ${subcommand}`);
            console.log("Available: add, remove, list");
            process.exit(1);
    }
}

async function handleTargetCommand(subcommand: string | undefined, args: string[]) {
    switch (subcommand) {
        case "add": {
            const name = args[0];
            const path = args[1];

            if (!name) {
                await interactiveTargetAdd();
                return;
            }

            await targetAdd(name, path);
            break;
        }

        case "remove": {
            const name = args[0];
            if (!name) {
                await interactiveTargetRemove();
                return;
            }
            await targetRemove(name);
            break;
        }

        case "list":
            await targetList();
            break;

        case "available":
            await targetAvailable();
            break;

        default:
            console.error(`Unknown target subcommand: ${subcommand}`);
            console.log("Available: add, remove, list, available");
            process.exit(1);
    }
}
