import { homedir } from "os";
import { join } from "path";

export interface KnownAgentsMdTarget {
    name: string;
    description: string;
    /** Target file path (where the symlink will be created) */
    path: string;
}

const home = homedir();

/**
 * Predefined target paths for AGENTS.md
 * Based on dotagents conventions:
 * - Claude Code expects CLAUDE.md at ~/.claude/CLAUDE.md
 * - Codex expects AGENTS.md at ~/.codex/AGENTS.md
 * - Gemini expects GEMINI.md at ~/.gemini/GEMINI.md
 * - Cursor expects .cursorrules or .cursor/rules/ (but prefers hardlinks)
 * - Windsurf expects AGENTS.md at ~/.windsurf/rules/AGENTS.md
 */
export const KNOWN_AGENTSMD_TARGETS: KnownAgentsMdTarget[] = [
    {
        name: "claude",
        description: "Claude Code / Claude Desktop",
        path: join(home, ".claude", "CLAUDE.md"),
    },
    {
        name: "codex",
        description: "OpenAI Codex",
        path: join(home, ".codex", "AGENTS.md"),
    },
    {
        name: "gemini",
        description: "Gemini CLI",
        path: join(home, ".gemini", "GEMINI.md"),
    },
    {
        name: "cursor",
        description: "Cursor IDE (rules file)",
        path: join(home, ".cursor", "rules", "global--agents.mdc"),
    },
    {
        name: "windsurf",
        description: "Windsurf IDE",
        path: join(home, ".windsurf", "AGENTS.md"),
    },
    {
        name: "factory",
        description: "Factory",
        path: join(home, ".factory", "AGENTS.md"),
    },
    {
        name: "antigravity",
        description: "Antigravity",
        path: join(home, ".gemini", "antigravity", "AGENTS.md"),
    },
];

/**
 * Get a known AGENTS.md target by name
 */
export function getKnownAgentsMdTarget(name: string): KnownAgentsMdTarget | undefined {
    return KNOWN_AGENTSMD_TARGETS.find(t => t.name.toLowerCase() === name.toLowerCase());
}

/**
 * Get all known AGENTS.md target names
 */
export function getKnownAgentsMdTargetNames(): string[] {
    return KNOWN_AGENTSMD_TARGETS.map(t => t.name);
}
