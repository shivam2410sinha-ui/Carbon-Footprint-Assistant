import * as p from "@clack/prompts";
import { lstat, rm, symlink, mkdir, stat } from "fs/promises";
import { resolve, dirname } from "path";
import chalk from "chalk";
import Table from "cli-table3";
import { addAgentsMdTarget, removeAgentsMdTarget, getAgentsMdTargets } from "../../lib/config.ts";
import { AGENTS_MD_SOURCE } from "../../lib/paths.ts";
import { getKnownAgentsMdTarget, KNOWN_AGENTSMD_TARGETS } from "./lib/known-targets.ts";
import type { AgentsMdTarget } from "./types.ts";

function printAgentsMdHelp() {
    console.log(`
${chalk.bold("agents agents-md")} - Manage AGENTS.md symlinks across AI tools

${chalk.bold("USAGE")}
  ${chalk.cyan("agents agents-md")} <command> [options]

${chalk.bold("COMMANDS")}
  ${chalk.cyan("status")}             Show AGENTS.md targets and sync status
  ${chalk.cyan("target list")}        List all targets
  ${chalk.cyan("target available")}   Show predefined targets
  ${chalk.cyan("target add")} [name]  Add a target
  ${chalk.cyan("target remove")} [n]  Remove a target
  ${chalk.cyan("sync")}               Sync AGENTS.md to all targets

${chalk.bold("NOTES")}
  Source file is at ~/.agents/AGENTS.md
  Edit this file manually - it syncs to all targets.
`);
}

/**
 * Safe symlink: create symlink, removing existing file/link if needed
 */
async function safeSymlink(source: string, target: string): Promise<void> {
    try {
        const stats = await lstat(target);
        if (stats.isSymbolicLink() || stats.isFile()) {
            await rm(target, { force: true });
        }
    } catch { /* Doesn't exist */ }

    // Ensure parent directory exists
    await mkdir(dirname(target), { recursive: true });

    // Use 'file' type for file symlinks (works on Windows with dev mode)
    await symlink(source, target, "file");
}

/**
 * Sync AGENTS.md to a target
 */
async function syncToTarget(target: AgentsMdTarget): Promise<void> {
    // Check source exists
    try {
        await stat(AGENTS_MD_SOURCE);
    } catch {
        throw new Error(`Source file not found: ${AGENTS_MD_SOURCE}`);
    }

    await safeSymlink(AGENTS_MD_SOURCE, target.path);
}

/**
 * Sync AGENTS.md to all targets
 */
async function sync(): Promise<void> {
    const targets = await getAgentsMdTargets();

    if (targets.length === 0) {
        console.log("No AGENTS.md targets registered.");
        console.log(`Add a target with: ${chalk.cyan("agents agents-md target add <name>")}`);
        return;
    }

    // Check source exists
    try {
        await stat(AGENTS_MD_SOURCE);
    } catch {
        console.log(chalk.yellow(`Source file not found: ${AGENTS_MD_SOURCE}`));
        console.log("Create it with your global agent instructions.");
        return;
    }

    console.log("Syncing AGENTS.md to targets...");
    for (const target of targets) {
        try {
            await syncToTarget(target);
            console.log(`  ${target.name}: ${chalk.green("✓")} ${target.path}`);
        } catch (error) {
            console.error(`  ${target.name}: ${chalk.red("✗")} ${error instanceof Error ? error.message : error}`);
        }
    }
    console.log("\nDone.");
}

/**
 * Add a target
 */
async function targetAdd(name: string, path?: string): Promise<void> {
    let absolutePath: string;

    if (path) {
        absolutePath = resolve(path.replace(/^~/, process.env.HOME || process.env.USERPROFILE || ""));
    } else {
        const known = getKnownAgentsMdTarget(name);
        if (!known) {
            console.error(chalk.red(`Unknown target: ${name}`));
            console.log(`Run ${chalk.cyan("agents agents-md target available")} to see predefined targets.`);
            process.exit(1);
        }
        absolutePath = known.path;
        console.log(`Using predefined path for ${chalk.cyan(known.description)}`);
    }

    console.log(`Adding target: ${chalk.cyan(name)}`);
    await addAgentsMdTarget({ name, path: absolutePath });

    // Immediately sync if source exists
    try {
        await stat(AGENTS_MD_SOURCE);
        await syncToTarget({ name, path: absolutePath });
        console.log(chalk.green(`Target "${name}" is now synced.`));
    } catch {
        console.log(chalk.yellow(`Note: ${AGENTS_MD_SOURCE} doesn't exist yet.`));
        console.log("Create it and run 'agents agents-md sync' to sync.");
    }
}

/**
 * Show available predefined targets
 */
async function targetAvailable(): Promise<void> {
    const existing = await getAgentsMdTargets();
    const existingNames = new Set(existing.map(t => t.name.toLowerCase()));

    console.log();
    console.log(chalk.bold("Available AGENTS.md Targets"));
    console.log(chalk.dim("─".repeat(60)));

    const table = new Table({
        head: [chalk.bold("Name"), chalk.bold("Description"), chalk.bold("Target Path"), chalk.bold("Added")],
        style: { head: [], border: [] },
    });

    for (const target of KNOWN_AGENTSMD_TARGETS) {
        const isAdded = existingNames.has(target.name.toLowerCase());
        table.push([target.name, target.description, target.path, isAdded ? chalk.green("✓") : chalk.dim("-")]);
    }

    console.log(table.toString());
    console.log();
}

/**
 * Remove a target
 */
async function targetRemove(name: string): Promise<void> {
    const removed = await removeAgentsMdTarget(name);
    if (!removed) throw new Error(`AGENTS.md target not found: ${name}`);
    console.log(`Removed target: ${name}`);
    console.log(`Note: Symlink at ${removed.path} was not deleted.`);
}

/**
 * List all targets
 */
async function targetList(): Promise<void> {
    const targets = await getAgentsMdTargets();
    if (targets.length === 0) { console.log("No AGENTS.md targets registered."); return; }

    const table = new Table({
        head: [chalk.bold("Name"), chalk.bold("Path"), chalk.bold("Status")],
        style: { head: [], border: [] },
    });

    for (const target of targets) {
        let status = "missing";
        try {
            const stats = await lstat(target.path);
            status = stats.isSymbolicLink() ? "synced" : "not symlink";
        } catch { /* missing */ }
        const statusDisplay = status === "synced" ? chalk.green(status) : chalk.yellow(status);
        table.push([target.name, target.path, statusDisplay]);
    }

    console.log();
    console.log(table.toString());
    console.log();
}

/**
 * Show status
 */
async function status(): Promise<void> {
    console.log();
    console.log(chalk.bold("AGENTS.md Status"));
    console.log(chalk.dim("─".repeat(40)));
    console.log(`Source: ${AGENTS_MD_SOURCE}`);

    try {
        await stat(AGENTS_MD_SOURCE);
        console.log(`Status: ${chalk.green("exists")}`);
    } catch {
        console.log(`Status: ${chalk.yellow("not created yet")}`);
    }

    console.log();
    await targetList();
}

// Interactive handlers
async function interactiveTargetAdd(): Promise<void> {
    const existing = await getAgentsMdTargets();
    const existingNames = new Set(existing.map(t => t.name.toLowerCase()));
    const available = KNOWN_AGENTSMD_TARGETS.filter(t => !existingNames.has(t.name.toLowerCase()));

    p.intro(chalk.bgCyan(chalk.black(" Add AGENTS.md Target ")));

    if (available.length === 0) {
        p.log.warn("All predefined targets have been added!");
        p.outro("Use 'agents agents-md target list' to see your targets.");
        return;
    }

    const name = await p.select({
        message: "Select target:",
        options: available.map(t => ({ value: t.name, label: t.name, hint: t.description })),
    });
    if (p.isCancel(name)) { p.cancel("Cancelled."); process.exit(0); }

    const s = p.spinner();
    s.start("Adding target...");
    try { await targetAdd(name); s.stop("Done!"); }
    catch (e) { s.stop("Failed"); p.log.error(e instanceof Error ? e.message : String(e)); process.exit(1); }
    p.outro(chalk.green("Target added!"));
}

async function interactiveTargetRemove(): Promise<void> {
    const targets = await getAgentsMdTargets();
    if (targets.length === 0) { p.log.warn("No targets to remove."); return; }

    p.intro(chalk.bgRed(chalk.white(" Remove AGENTS.md Target ")));
    const name = await p.select({
        message: "Which target?",
        options: targets.map(t => ({ value: t.name, label: t.name, hint: t.path })),
    });
    if (p.isCancel(name)) { p.cancel("Cancelled."); process.exit(0); }

    const confirmed = await p.confirm({ message: `Remove "${name}"?` });
    if (p.isCancel(confirmed) || !confirmed) { p.cancel("Cancelled."); process.exit(0); }

    try { await targetRemove(name); p.outro(chalk.green("Removed!")); }
    catch (e) { p.log.error(e instanceof Error ? e.message : String(e)); process.exit(1); }
}

async function interactiveMainMenu(): Promise<void> {
    p.intro(chalk.bgCyan(chalk.black(" AGENTS.md Management ")));

    const action = await p.select({
        message: "What would you like to do?",
        options: [
            { value: "status", label: "View status" },
            { value: "target-add", label: "Add a target" },
            { value: "target-remove", label: "Remove a target" },
            { value: "target-list", label: "List targets" },
            { value: "sync", label: "Sync to all targets" },
        ],
    });
    if (p.isCancel(action)) { p.cancel("Goodbye!"); process.exit(0); }

    console.log();
    switch (action) {
        case "status": await status(); break;
        case "target-add": await interactiveTargetAdd(); break;
        case "target-remove": await interactiveTargetRemove(); break;
        case "target-list": await targetList(); break;
        case "sync": await sync(); break;
    }
}

export async function handleAgentsMdCommand(args: string[]): Promise<void> {
    if (args.includes("--help") || args.includes("-h")) { printAgentsMdHelp(); return; }
    if (args.length === 0) { await interactiveMainMenu(); return; }

    const command = args[0];
    if (!command) return;

    switch (command) {
        case "target": {
            const sub = args[1];
            switch (sub) {
                case "add": {
                    const n = args[2];
                    if (!n) { await interactiveTargetAdd(); return; }
                    await targetAdd(n, args[3]);
                    break;
                }
                case "remove": {
                    const n = args[2];
                    if (!n) { await interactiveTargetRemove(); return; }
                    await targetRemove(n);
                    break;
                }
                case "list": await targetList(); break;
                case "available": await targetAvailable(); break;
                default: console.error(`Unknown: ${sub}`); process.exit(1);
            }
            break;
        }
        case "sync": await sync(); break;
        case "status": await status(); break;
        case "help": printAgentsMdHelp(); break;
        default:
            console.error(chalk.red(`Unknown command: ${command}`));
            process.exit(1);
    }
}
