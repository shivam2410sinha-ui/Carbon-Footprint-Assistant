/**
 * AGENTS.md Target - where AGENTS.md is synced to
 */
export interface AgentsMdTarget {
    /** User-friendly name (e.g., "cursor") */
    name: string;
    /** Absolute path to target file (e.g., ~/.claude/CLAUDE.md) */
    path: string;
}
