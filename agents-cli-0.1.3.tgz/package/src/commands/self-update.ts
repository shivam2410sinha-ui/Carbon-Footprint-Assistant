import chalk from "chalk";

const PACKAGE_NAME = "agents-cli";

/**
 * Get the currently installed version
 */
export async function getCurrentVersion(): Promise<string | null> {
    try {
        // Try to get from package.json first if running local
        // But for global install, we might want to check bun pm ls
        // Let's try bun pm ls -g first as it's more accurate for global installs
        const proc = Bun.spawn(["bun", "pm", "ls", "-g"], {
            stdout: "pipe",
            stderr: "pipe",
        });
        const output = await new Response(proc.stdout).text();
        await proc.exited;

        // Parse output to find our package version
        const lines = output.split("\n");
        for (const line of lines) {
            if (line.includes(PACKAGE_NAME)) {
                // Format: "agents-cli@1.1.0" or similar
                const match = line.match(/agents-cli@([\d.]+)/);
                if (match) {
                    return match[1] || null;
                }
            }
        }

        // Fallback: try to require package.json (might not work in compiled binary depending on how it's built, but works in source)
        // In Bun, we can also import it
        return null;
    } catch {
        return null;
    }
}

/**
 * Get the latest version from npm registry
 */
export async function getLatestVersion(): Promise<string | null> {
    try {
        const response = await fetch(`https://registry.npmjs.org/${PACKAGE_NAME}/latest`);
        if (!response.ok) return null;
        const data = await response.json() as { version: string };
        return data.version;
    } catch {
        // Fail silently (offline, etc)
        return null;
    }
}

/**
 * Check for updates and notify user
 * Returns true if update is available
 */
export async function checkForUpdate(): Promise<boolean> {
    const current = await getCurrentVersion();
    const latest = await getLatestVersion();

    if (current && latest && current !== latest) {
        console.log();
        console.log(chalk.yellow("┌─────────────────────────────────────────────────────────────┐"));
        console.log(chalk.yellow("│                                                             │"));
        console.log(chalk.yellow(`│   Update available! ${chalk.red(current)} → ${chalk.green(latest)}                           │`));
        console.log(chalk.yellow(`│   Run ${chalk.cyan("agents update")} to upgrade                               │`));
        console.log(chalk.yellow("│                                                             │"));
        console.log(chalk.yellow("└─────────────────────────────────────────────────────────────┘"));
        console.log();
        return true;
    }
    return false;
}

/**
 * Self-update the CLI to the latest version
 */
export async function selfUpdate(): Promise<void> {
    console.log();
    console.log(chalk.bold("Updating agents CLI..."));
    console.log();

    // Get current version
    const currentVersion = await getCurrentVersion();
    if (currentVersion) {
        console.log(`  Current version: ${chalk.cyan(`v${currentVersion}`)}`);
    }

    // Check latest version
    const latestVersion = await getLatestVersion();
    if (latestVersion) {
        console.log(`  Latest version:  ${chalk.green(`v${latestVersion}`)}`);
    }

    if (currentVersion && latestVersion && currentVersion === latestVersion) {
        console.log();
        console.log(chalk.green("✓ Already up to date!"));
        console.log();
        return;
    }

    console.log();
    console.log(chalk.dim(`Running: bun install -g ${PACKAGE_NAME}`));
    console.log();

    // Run the update command
    const proc = Bun.spawn(["bun", "install", "-g", PACKAGE_NAME], {
        stdout: "inherit",
        stderr: "inherit",
    });

    const exitCode = await proc.exited;

    if (exitCode === 0) {
        console.log();
        console.log(chalk.green("✓ Successfully updated agents CLI!"));

        // Show new version
        const newVersion = await getCurrentVersion();
        if (newVersion) {
            console.log(`  New version: ${chalk.green(`v${newVersion}`)}`);
        }
        console.log();
    } else {
        console.log();
        console.error(chalk.red("✗ Failed to update. Please try manually:"));
        console.log(`  ${chalk.cyan(`bun install -g ${PACKAGE_NAME}`)}`);
        console.log();
        process.exit(1);
    }
}
